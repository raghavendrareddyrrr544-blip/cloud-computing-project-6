// ===============================
// PRODUCT DATA
// ===============================

let products = [
    {
        id: 1,
        name: "Wireless Headphones",
        category: "Electronics",
        price: 1999,
        icon: "fa-headphones"
    },

    {
        id: 2,
        name: "Smart Watch",
        category: "Electronics",
        price: 2499,
        icon: "fa-clock"
    },

    {
        id: 3,
        name: "Premium T-Shirt",
        category: "Fashion",
        price: 899,
        icon: "fa-shirt"
    },

    {
        id: 4,
        name: "Running Shoes",
        category: "Fashion",
        price: 2999,
        icon: "fa-shoe-prints"
    },

    {
        id: 5,
        name: "Table Lamp",
        category: "Home",
        price: 799,
        icon: "fa-lightbulb"
    },

    {
        id: 6,
        name: "Coffee Maker",
        category: "Home",
        price: 3499,
        icon: "fa-mug-hot"
    },

    {
        id: 7,
        name: "Backpack",
        category: "Accessories",
        price: 1299,
        icon: "fa-briefcase"
    },

    {
        id: 8,
        name: "Sunglasses",
        category: "Accessories",
        price: 699,
        icon: "fa-glasses"
    }
];


// ===============================
// CART
// ===============================

let cart = JSON.parse(localStorage.getItem("cart")) || [];


// ===============================
// DISPLAY PRODUCTS
// ===============================

function displayProducts(productList = products) {

    const container = document.getElementById("productContainer");

    container.innerHTML = "";

    if (productList.length === 0) {

        container.innerHTML = `
            <div style="grid-column:1/-1;text-align:center;padding:50px">
                <h3>No products found</h3>
            </div>
        `;

        return;
    }

    productList.forEach(product => {

        container.innerHTML += `

            <div class="product-card">

                <div class="product-image">

                    <i class="fa-solid ${product.icon}"></i>

                </div>

                <div class="product-info">

                    <span class="product-category">
                        ${product.category}
                    </span>

                    <h3>${product.name}</h3>

                    <div class="product-price">
                        ₹${product.price.toLocaleString("en-IN")}
                    </div>

                    <button
                        class="add-cart"
                        onclick="addToCart(${product.id})"
                    >
                        <i class="fa-solid fa-cart-plus"></i>
                        Add to Cart
                    </button>

                </div>

            </div>
        `;
    });
}


// ===============================
// ADD TO CART
// ===============================

function addToCart(productId) {

    const product = products.find(p => p.id === productId);

    const existing = cart.find(item => item.id === productId);

    if (existing) {

        existing.quantity++;

    } else {

        cart.push({
            ...product,
            quantity: 1
        });

    }

    saveCart();

    updateCart();

    alert(`${product.name} added to cart!`);
}


// ===============================
// SAVE CART
// ===============================

function saveCart() {

    localStorage.setItem(
        "cart",
        JSON.stringify(cart)
    );
}


// ===============================
// UPDATE CART
// ===============================

function updateCart() {

    const count = cart.reduce(
        (total, item) => total + item.quantity,
        0
    );

    document.getElementById("cartCount").textContent = count;

    displayCart();
}


// ===============================
// DISPLAY CART
// ===============================

function displayCart() {

    const container = document.getElementById("cartItems");

    const totalElement = document.getElementById("cartTotal");

    if (!container) return;

    container.innerHTML = "";

    if (cart.length === 0) {

        container.innerHTML = `
            <div style="text-align:center;padding:30px">
                <i
                    class="fa-solid fa-cart-shopping"
                    style="font-size:40px;color:#5b3df5"
                ></i>

                <p style="margin-top:15px">
                    Your cart is empty.
                </p>
            </div>
        `;

        totalElement.textContent = "₹0";

        return;
    }

    let total = 0;

    cart.forEach(item => {

        total += item.price * item.quantity;

        container.innerHTML += `

            <div class="cart-item">

                <div class="cart-item-info">

                    <h4>${item.name}</h4>

                    <p>
                        ₹${item.price.toLocaleString("en-IN")}
                    </p>

                </div>

                <div class="quantity">

                    <button
                        onclick="changeQuantity(${item.id}, -1)"
                    >
                        -
                    </button>

                    <span>${item.quantity}</span>

                    <button
                        onclick="changeQuantity(${item.id}, 1)"
                    >
                        +
                    </button>

                </div>

                <button
                    class="remove-btn"
                    onclick="removeFromCart(${item.id})"
                >
                    <i class="fa-solid fa-trash"></i>
                </button>

            </div>
        `;
    });

    totalElement.textContent =
        `₹${total.toLocaleString("en-IN")}`;
}


// ===============================
// CHANGE QUANTITY
// ===============================

function changeQuantity(productId, change) {

    const item = cart.find(
        item => item.id === productId
    );

    if (!item) return;

    item.quantity += change;

    if (item.quantity <= 0) {

        cart = cart.filter(
            item => item.id !== productId
        );

    }

    saveCart();

    updateCart();
}


// ===============================
// REMOVE FROM CART
// ===============================

function removeFromCart(productId) {

    cart = cart.filter(
        item => item.id !== productId
    );

    saveCart();

    updateCart();
}


// ===============================
// OPEN CART
// ===============================

function openCart() {

    document.getElementById("cartModal").style.display = "flex";

    displayCart();
}


// ===============================
// CLOSE CART
// ===============================

function closeCart() {

    document.getElementById("cartModal").style.display = "none";
}


// ===============================
// LOGIN
// ===============================

function openLogin() {

    document.getElementById("loginModal").style.display = "flex";
}


function closeLogin() {

    document.getElementById("loginModal").style.display = "none";
}


function login() {

    const email =
        document.getElementById("loginEmail").value;

    const password =
        document.getElementById("loginPassword").value;

    if (!email || !password) {

        alert("Please enter email and password.");

        return;
    }

    alert("Login system will connect to the backend.");

    closeLogin();
}


function register() {

    alert("Registration page will be connected to the backend.");
}


// ===============================
// SEARCH
// ===============================

function searchProducts() {

    const search =
        document.getElementById("searchInput")
        .value
        .toLowerCase();

    const filtered = products.filter(product =>

        product.name.toLowerCase().includes(search) ||

        product.category.toLowerCase().includes(search)

    );

    displayProducts(filtered);
}


// ===============================
// CATEGORY FILTER
// ===============================

function filterCategory(category) {

    const filtered = products.filter(
        product => product.category === category
    );

    displayProducts(filtered);

    document.getElementById("products")
        .scrollIntoView({
            behavior: "smooth"
        });
}


// ===============================
// SORT PRODUCTS
// ===============================

function sortProducts() {

    const value =
        document.getElementById("sortProducts").value;

    let sorted = [...products];

    if (value === "low") {

        sorted.sort(
            (a, b) => a.price - b.price
        );

    }

    if (value === "high") {

        sorted.sort(
            (a, b) => b.price - a.price
        );

    }

    displayProducts(sorted);
}


// ===============================
// CHECKOUT
// ===============================

function checkout() {

    if (cart.length === 0) {

        alert("Your cart is empty.");

        return;
    }

    alert(
        "Checkout and payment gateway will be connected here."
    );
}


// ===============================
// SCROLL PRODUCTS
// ===============================

function scrollToProducts() {

    document.getElementById("products")
        .scrollIntoView({
            behavior: "smooth"
        });
}


// ===============================
// INITIALIZE
// ===============================

displayProducts();

updateCart();