require("dotenv").config();

const express = require("express");
const cors = require("cors");
const path = require("path");

const app = express();

app.use(cors());
app.use(express.json());


// Serve frontend files
app.use(express.static(__dirname));


// Home route
app.get("/", (req, res) => {

    res.sendFile(
        path.join(__dirname, "index.html")
    );

});


// Health check
app.get("/api/health", (req, res) => {

    res.json({
        success: true,
        message: "ShopEase API is running"
    });

});


// Products API
app.get("/api/products", (req, res) => {

    res.json({
        success: true,
        message: "Products API working"
    });

});


const PORT = process.env.PORT || 5000;

app.listen(PORT, () => {

    console.log(
        `ShopEase server running at http://localhost:${PORT}`
    );

});